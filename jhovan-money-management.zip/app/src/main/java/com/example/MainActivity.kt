package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainDashboardView
import com.example.ui.MoneyViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MoneyViewModel = viewModel()
      val themeAccentColor by viewModel.themeAccentColor.collectAsStateWithLifecycle()

      MyApplicationTheme(accentColorHex = themeAccentColor) {
        MainDashboardView(viewModel = viewModel)
      }
    }
  }
}
