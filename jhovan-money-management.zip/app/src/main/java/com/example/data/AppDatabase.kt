package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Transaction::class, Category::class, Wallet::class, Budget::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun moneyDao(): MoneyDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "jhovandb_money_manager"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    val dao = database.moneyDao()
                    
                    // Prepopulate Wallets
                    dao.insertWallet(Wallet("Stark Pay Card", 25000000.0, "CreditCard", "#00E5FF"))
                    dao.insertWallet(Wallet("Cash Vault", 750000.0, "AccountBalanceWallet", "#B0BEC5"))
                    dao.insertWallet(Wallet("Google Wallet", 1250000.0, "AccountBalance", "#FFA726"))

                    // Prepopulate Categories - Expenses
                    dao.insertCategory(Category("Arc Reactor Fuel", "Bolt", "#FF3D00", true))
                    dao.insertCategory(Category("Stark Labs Tech", "Build", "#00E5FF", true))
                    dao.insertCategory(Category("Food & Dining", "Restaurant", "#FFD54F", true))
                    dao.insertCategory(Category("Transport", "DirectionsCar", "#4FC3F7", true))
                    dao.insertCategory(Category("Entertainment", "Celebrity", "#BA68C8", true))
                    dao.insertCategory(Category("Subscriptions", "CardMembership", "#81C784", true))
                    dao.insertCategory(Category("Other Expenses", "Category", "#90A4AE", true))

                    // Prepopulate Categories - Incomes
                    dao.insertCategory(Category("Stark Fellowship", "Stars", "#FFA726", false))
                    dao.insertCategory(Category("Business Revenue", "TrendingUp", "#00E5FF", false))
                    dao.insertCategory(Category("Salary", "MonetizationOn", "#81C784", false))
                    dao.insertCategory(Category("Other Incomes", "AddCircle", "#90A4AE", false))
                }
            }
        }
    }
}
