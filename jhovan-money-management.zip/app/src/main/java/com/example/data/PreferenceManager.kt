package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jhovandb_preferences")

class PreferenceManager(private val context: Context) {

    companion object {
        val KEY_USER_NAME = stringPreferencesKey("user_name")
        val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        val KEY_IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val KEY_PROFILE_AVATAR = stringPreferencesKey("profile_avatar") // "Stark", "JarvisAdmin", "Rescue"
        val KEY_CLEARANCE_LEVEL = stringPreferencesKey("clearance_level") // "Level 5", "Core Director", etc
        val KEY_THEME_ACCENT_COLOR = stringPreferencesKey("theme_accent_color") // "#00E5FF", etc
        val KEY_JARVIS_CHATTER_FREQ = floatPreferencesKey("jarvis_chatter_freq") // 0.0f - 1.0f
    }

    val userNameFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_USER_NAME] ?: "Agent JHOVAN"
    }

    val userEmailFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_USER_EMAIL] ?: "atysinr@gmail.com"
    }

    val isLoggedInFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_IS_LOGGED_IN] ?: false
    }

    val profileAvatarFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_PROFILE_AVATAR] ?: "JarvisAdmin"
    }

    val clearanceLevelFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_CLEARANCE_LEVEL] ?: "Omega Clearance"
    }

    val themeAccentColorFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_THEME_ACCENT_COLOR] ?: "#00E5FF" // Default Stark Glowing Cyan
    }

    val jarvisChatterFreqFlow: Flow<Float> = context.dataStore.data.map { preferences ->
        preferences[KEY_JARVIS_CHATTER_FREQ] ?: 0.8f
    }

    suspend fun saveProfile(name: String, email: String, isLoggedIn: Boolean, avatar: String, clearance: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_USER_NAME] = name
            preferences[KEY_USER_EMAIL] = email
            preferences[KEY_IS_LOGGED_IN] = isLoggedIn
            preferences[KEY_PROFILE_AVATAR] = avatar
            preferences[KEY_CLEARANCE_LEVEL] = clearance
        }
    }

    suspend fun saveThemeAccent(colorHex: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_THEME_ACCENT_COLOR] = colorHex
        }
    }

    suspend fun saveJarvisChatterFreq(frequency: Float) {
        context.dataStore.edit { preferences ->
            preferences[KEY_JARVIS_CHATTER_FREQ] = frequency
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { preferences ->
            preferences[KEY_IS_LOGGED_IN] = false
            preferences[KEY_USER_NAME] = "Guest Agent"
            preferences[KEY_USER_EMAIL] = ""
            preferences[KEY_CLEARANCE_LEVEL] = "Level 1 Guest"
        }
    }
}
