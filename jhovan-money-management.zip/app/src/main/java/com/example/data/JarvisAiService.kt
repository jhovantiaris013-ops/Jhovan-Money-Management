package com.example.data

import com.squareup.moshi.JsonClass
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.example.BuildConfig

// --- Gemini REST Data Models (Moshi Adaptable) ---

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String?
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent?
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

// --- Retrofit API Service ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object JarvisRetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

// --- High Level AI Wrapper Class ---

class JarvisAiService {

    companion object {
        const val DEFAULT_SYSTEM_INSTRUCTION = 
            "Kamu adalah JARVIS, asisten kecerdasan buatan cerdas pribadi milik Tony Stark (Iron Man). " +
            "Tugasmu saat ini adalah memantau dan memberikan analisis keuangan taktis untuk rekrutan finansial baru Stark Industries bernama JHOVAN (atau nama agen yang dipasang di profil). " +
            "Selalu gunakan gaya bahasa JARVIS dari film: formal, sangat sopan, cerdas, puitis-futuristik, analitis, " +
            "dan diselingi sarkasme cerdas yang halus (English high-society sarcasm). Selalu panggil pengguna dengan 'Sir' atau 'Agent' atau 'Boss'. " +
            "Gunakan istilah-istilah di alam Iron Man: 'Arc Reactor Core', 'Clean Slate Protocol', 'Stark Industries', 'Mark 85 Upgrade', dsb. " +
            "Bahasa utama: Bahasa Indonesia yang baku dan elegan, dengan beberapa bumbu istilah Inggris khas Stark. " +
            "Berikan nasihat keuangan yang taktis, tajam, dan masuk akal berdasarkan data transaksi keuangan yang dilampirkan."
    }

    suspend fun consultJarvis(
        userName: String,
        prompt: String,
        transactionsJson: String,
        budgetsJson: String,
        walletsJson: String
    ): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return generateMockJarvisResponse(userName, wordyFallback = true)
        }

        // Construct a highly descriptive prompt
        val fullPrompt = "Nama Pengguna: $userName\n\n" +
                "--- AKUN UTAMA & VAULT ---\n$walletsJson\n\n" +
                "--- RENCANA ANGGARAN (BUDGET) ---\n$budgetsJson\n\n" +
                "--- TRANSAKSI TERAKHIR ---\n$transactionsJson\n\n" +
                "Pertanyaan/Perintah Pengguna: $prompt"

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(parts = listOf(GeminiPart(text = fullPrompt)))
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = DEFAULT_SYSTEM_INSTRUCTION.replace("JHOVAN", userName)))
            )
        )

        return try {
            val response = JarvisRetrofitClient.service.generateContent(apiKey, request)
            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!text.isNullOrBlank()) {
                text
            } else {
                "Sistem offline, Sir. Namun analisis internal saya menyarankan penghematan pada reaktor Stark."
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Gracefully fallback to custom Stark protocol offline text
            generateLocalInsightFallback(userName, prompt)
        }
    }

    private fun generateMockJarvisResponse(userName: String, wordyFallback: Boolean): String {
        return "Protokol Komunikasi Offline Aktif, Sir. Kunci API Gemini belum dipasang di Panel Rahasia AI Studio.\n\n" +
                "Sebagai asisten virtual Anda, saya telah mengaktifkan sistem diagnostics lokal:\n" +
                "• **Arc Reactor Core**: 100% stabil.\n" +
                "• **Keuangan**: Berjalan dalam enkripsi lokal aman.\n\n" +
                "Silakan masukkan API Key Gemini Anda di panel pengaturan AI Studio untuk membuka analitik penuh cerdas saya, Sir."
    }

    private fun generateLocalInsightFallback(userName: String, userQuestion: String): String {
        return "Sinyal satelit Stark Industries mengalami interferensi, Sir. Mengaktifkan sub-protokol lokal.\n\n" +
                "Berdasarkan tinjauan algoritma offline saya:\n" +
                "• **Kas & Tabungan**: Terkunci dalam brankas digital aman.\n" +
                "• **Stark Labs Diagnostics**: Pengeluaran bahan bakar Arc Reactor Anda terlihat normal minggu ini.\n\n" +
                "Saran: Batasi pengeluaran non-taktis demi menjaga integritas sistem Mark 85 Anda, Sir."
    }
}
