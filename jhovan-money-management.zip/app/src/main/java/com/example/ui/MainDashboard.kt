package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Budget
import com.example.data.Category
import com.example.data.Transaction
import com.example.data.Wallet
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

sealed class Screen(val title: String, val icon: ImageVector) {
    object Dashboard : Screen("Vitals", Icons.Default.Adjust)
    object Transactions : Screen("Ledger", Icons.Default.MenuBook)
    object Budgets : Screen("Budgets", Icons.Default.PieChart)
    object JarvisAI : Screen("JARVIS", Icons.Default.Psychology)
    object Settings : Screen("Clearance", Icons.Default.AdminPanelSettings)
}

@Composable
fun MainDashboardView(viewModel: MoneyViewModel) {
    val coroutineScope = rememberCoroutineScope()
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }

    // Collect App Theme & Profile Details
    val themeAccentColor by viewModel.themeAccentColor.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val userEmail by viewModel.userEmail.collectAsStateWithLifecycle()
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val clearanceLevel by viewModel.clearanceLevel.collectAsStateWithLifecycle()
    val avatarType by viewModel.profileAvatar.collectAsStateWithLifecycle()

    // Collect Database Lists
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val wallets by viewModel.wallets.collectAsStateWithLifecycle()
    val budgets by viewModel.budgets.collectAsStateWithLifecycle()

    // Parse Theme Accent safely
    val customAccent = try {
        Color(android.graphics.Color.parseColor(themeAccentColor))
    } catch (e: Exception) {
        Color(0xFF00E5FF)
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF060D1E),
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("app_navigation_bar")
            ) {
                val screens = listOf(
                    Screen.Dashboard,
                    Screen.Transactions,
                    Screen.Budgets,
                    Screen.JarvisAI,
                    Screen.Settings
                )
                screens.forEach { screen ->
                    val isSelected = currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                screen.icon,
                                contentDescription = screen.title,
                                tint = if (isSelected) customAccent else Color.White.copy(alpha = 0.5f)
                            )
                        },
                        label = {
                            Text(
                                screen.title,
                                color = if (isSelected) customAccent else Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = customAccent.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF030812),
                            Color(0xFF051124)
                        )
                    )
                )
        ) {
            // Background grid visualizer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        val strokeWidth = 1f
                        val gridSize = 60.dp.toPx()
                        
                        // Draw grid lines
                        for (x in 0..size.width.toInt() step gridSize.toInt()) {
                            drawLine(
                                color = Color(0xFF102A4A).copy(alpha = 0.12f),
                                start = Offset(x.toFloat(), 0f),
                                end = Offset(x.toFloat(), size.height),
                                strokeWidth = strokeWidth
                            )
                        }
                        for (y in 0..size.height.toInt() step gridSize.toInt()) {
                            drawLine(
                                color = Color(0xFF102A4A).copy(alpha = 0.12f),
                                start = Offset(0f, y.toFloat()),
                                end = Offset(size.width, y.toFloat()),
                                strokeWidth = strokeWidth
                            )
                        }
                    }
            )

            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220, easing = LinearEasing)) togetherWith
                            fadeOut(animationSpec = tween(150, easing = LinearEasing))
                },
                label = "screen_transition"
            ) { targetScreen ->
                when (targetScreen) {
                    is Screen.Dashboard -> DashboardScreen(
                        viewModel = viewModel,
                        transactions = transactions,
                        wallets = wallets,
                        accentColor = customAccent,
                        avatarType = avatarType,
                        userName = userName,
                        clearance = clearanceLevel
                    )
                    is Screen.Transactions -> TransactionsScreen(
                        viewModel = viewModel,
                        transactions = transactions,
                        categories = categories,
                        wallets = wallets,
                        accentColor = customAccent
                    )
                    is Screen.Budgets -> BudgetsScreen(
                        viewModel = viewModel,
                        budgets = budgets,
                        transactions = transactions,
                        categories = categories,
                        wallets = wallets,
                        accentColor = customAccent
                    )
                    is Screen.JarvisAI -> JarvisChatScreen(
                        viewModel = viewModel,
                        accentColor = customAccent
                    )
                    is Screen.Settings -> SettingsScreen(
                        viewModel = viewModel,
                        accentColor = customAccent,
                        categories = categories,
                        userName = userName,
                        userEmail = userEmail,
                        isLoggedIn = isLoggedIn,
                        clearanceLevel = clearanceLevel,
                        avatarType = avatarType
                    )
                }
            }
        }
    }
}

// ======================== SCREEN 1: DASHBOARD (VITALS) ========================

@Composable
fun DashboardScreen(
    viewModel: MoneyViewModel,
    transactions: List<Transaction>,
    wallets: List<Wallet>,
    accentColor: Color,
    avatarType: String,
    userName: String,
    clearance: String
) {
    val coroutineScope = rememberCoroutineScope()
    
    // Calculates summary statistics based on currency format
    val totalBalance = wallets.sumOf { it.balance }
    
    // Monthly calculation (current month)
    val calendar = Calendar.getInstance()
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    val startOfMonth = calendar.timeInMillis

    val monthlyIncome = transactions
        .filter { it.type == "INCOME" && it.timestamp >= startOfMonth }
        .sumOf { it.amount }

    val monthlyExpense = transactions
        .filter { it.type == "EXPENSE" && it.timestamp >= startOfMonth }
        .sumOf { it.amount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp)
    ) {
        // Stark Header Greeting Card
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Avatar badge
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f))
                        .border(1.5.dp, accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when (avatarType) {
                        "Stark" -> Icons.Default.Shield
                        "Rescue" -> Icons.Default.MonitorHeart
                        "WarMachine" -> Icons.Default.MilitaryTech
                        else -> Icons.Default.SmartToy
                    }
                    Icon(
                        icon,
                        contentDescription = "Avatar",
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "WELCOME BACK, SIR",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.5f),
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = userName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                
                // Clearance Indicator
                Badge(
                    containerColor = accentColor.copy(alpha = 0.15f),
                    modifier = Modifier.border(0.5.dp, accentColor, RoundedCornerShape(4.dp))
                ) {
                    Text(
                        text = clearance.uppercase(),
                        color = accentColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        // ARC REACTOR INTERACTIVE VIBE
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                var localCorePrompt by remember { mutableStateOf(0) }
                
                ArcReactorCore(
                    pulseColor = accentColor,
                    onTapReactor = {
                        localCorePrompt++
                        // Clicking releases a Jarvis easter egg in the logs
                        viewModel.askJarvis("RE-CALIBRATE PROTOCOL: Arc Reactor core tapped. Diagnostic value: $localCorePrompt")
                    }
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "ARC REACTOR STARK INTELLIGENCE CORE",
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor,
                    letterSpacing = 1.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Pulse Status: Online | Local Encription",
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.4f)
                )
            }
        }

        // PRIMARY balance container
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .border(
                        BorderStroke(1.dp, Brush.radialGradient(listOf(accentColor, Color.Transparent))),
                        shape = RoundedCornerShape(16.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF091428).copy(alpha = 0.85f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GLOBAL SECURED BALANCE",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.6f),
                            letterSpacing = 1.sp
                        )
                        Icon(
                            Icons.Default.VerifiedUser,
                            contentDescription = "Secured",
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Rp %,.2f".format(totalBalance),
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("app_global_balance")
                    )
                    
                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(color = Color(0xFF142F54))
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        // Monthly Income
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFF81C784), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("MONTHLY INCOME", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Rp %,.2f".format(monthlyIncome),
                                color = Color(0xFF81C784),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        
                        // Monthly Expense
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFFFF5252), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("MONTHLY EXPENSE", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Rp %,.2f".format(monthlyExpense),
                                color = Color(0xFFFF5252),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // SECTIONS: ACTIVE WALLETS / SYSTEMS
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VAULTS & ACCOUNTS",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${wallets.size} nodes active",
                    fontSize = 11.sp,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Horizontal Row of Wallet Cards
        item {
            if (wallets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(12.dp))
                        .background(Color(0xFF071424).copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No wallets available. Create one in budgets panel.", color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp)
                }
            } else {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(wallets) { wallet ->
                        val walletColor = try {
                            Color(android.graphics.Color.parseColor(wallet.colorHex))
                        } catch (e: Exception) {
                            accentColor
                        }
                        
                        Card(
                            modifier = Modifier
                                .width(160.dp)
                                .height(100.dp)
                                .border(
                                    BorderStroke(1.dp, walletColor.copy(alpha = 0.4f)),
                                    RoundedCornerShape(12.dp)
                                ),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF09172E)),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val icon = when (wallet.iconName) {
                                        "CreditCard" -> Icons.Default.CreditCard
                                        "AccountBalance" -> Icons.Default.AccountBalance
                                        "AccountBalanceWallet" -> Icons.Default.AccountBalanceWallet
                                        else -> Icons.Default.Wallet
                                    }
                                    Icon(
                                        icon,
                                        contentDescription = "Wallet Icon",
                                        tint = walletColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = wallet.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Column {
                                    Text(
                                        text = "WALLET VOLUME",
                                        fontSize = 8.sp,
                                        color = Color.White.copy(alpha = 0.4f)
                                    )
                                    Text(
                                        text = "Rp %,.0f".format(wallet.balance),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // SECTIONS: CRITICAL MOVEMENT RECENT RECORDS
        item {
            Text(
                text = "RECENT LEDGER JOURNAL",
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (transactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Ledger completely clear. Add elements inside Ledger ledger.",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(transactions.take(5)) { tx ->
                TransactionListItem(
                    transaction = tx,
                    accentColor = accentColor,
                    onDelete = { viewModel.deleteTransaction(tx) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

// ARC REACTOR COMPOSABLE DRAWING INSIDE CANVAS
@Composable
fun ArcReactorCore(
    modifier: Modifier = Modifier,
    pulseColor: Color = Color(0xFF00E5FF),
    onTapReactor: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = modifier
            .size(150.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                onClick = onTapReactor,
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = size.center
            val radius = size.minDimension / 2
            
            // Outer cyan glowing halo
            drawCircle(
                color = pulseColor.copy(alpha = 0.12f),
                radius = radius * 0.95f
            )

            // Outer technical ring
            drawCircle(
                color = pulseColor,
                radius = radius * 0.85f,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            
            // Segmented active rotor spinner
            rotate(rotation) {
                for (i in 0 until 6) {
                    val angle = (i * 60f)
                    drawArc(
                        color = pulseColor,
                        startAngle = angle + 4f,
                        sweepAngle = 52f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius * 0.72f, center.y - radius * 0.72f),
                        size = Size(radius * 1.44f, radius * 1.44f),
                        style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            
            // Middle ring
            drawCircle(
                color = pulseColor.copy(alpha = 0.4f),
                radius = radius * 0.50f,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Rotating inner rotor core
            rotate(-rotation * 1.5f) {
                for (i in 0 until 3) {
                    val innerAngle = (i * 120f)
                    drawArc(
                        color = pulseColor,
                        startAngle = innerAngle + 10f,
                        sweepAngle = 100f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius * 0.38f, center.y - radius * 0.38f),
                        size = Size(radius * 0.76f, radius * 0.76f),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Power Center circle
            drawCircle(
                color = pulseColor,
                radius = radius * 0.20f
            )
            drawCircle(
                color = Color.White,
                radius = radius * 0.10f
            )
        }
    }
}

// Transaction item renderer shared across panes
@Composable
fun TransactionListItem(
    transaction: Transaction,
    accentColor: Color,
    onDelete: () -> Unit
) {
    val isExpense = transaction.type == "EXPENSE"
    val stateColor = if (isExpense) Color(0xFFFF5252) else Color(0xFF66BB6A)
    
    val format = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    val formattedDate = format.format(Date(transaction.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF102A4A).copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF081427))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rounded status box
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(stateColor.copy(alpha = 0.15f))
                    .border(0.5.dp, stateColor, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isExpense) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    contentDescription = transaction.type,
                    tint = stateColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${transaction.categoryName} • $formattedDate • ${transaction.walletName}",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isExpense) "-" else "+"} Rp ${String.format("%,.0f", transaction.amount)}",
                    color = stateColor,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = Color.White.copy(alpha = 0.3f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}


// ======================== SCREEN 2: TRANSACTIONS (LEDGER) ========================

@Composable
fun TransactionsScreen(
    viewModel: MoneyViewModel,
    transactions: List<Transaction>,
    categories: List<Category>,
    wallets: List<Wallet>,
    accentColor: Color
) {
    var showAddDialog by remember { mutableStateOf(false) }

    // Filtering Options
    var selectedWalletFilter by remember { mutableStateOf("ALL") }
    var selectedTypeFilter by remember { mutableStateOf("ALL") }

    val filteredTransactions = transactions.filter { tx ->
        val matchWallet = selectedWalletFilter == "ALL" || tx.walletName == selectedWalletFilter
        val matchType = selectedTypeFilter == "ALL" || tx.type == selectedTypeFilter
        matchWallet && matchType
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = accentColor,
                contentColor = Color.Black,
                modifier = Modifier
                    .padding(bottom = 16.dp)
                    .testTag("add_transaction_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Transaction")
            }
        },
        containerColor = Color.Transparent
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = "LEDGER ALLOCATOR",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 24.dp, bottom = 4.dp)
            )
            Text(
                text = "System secure transactional journal ledger database",
                fontWeight = FontWeight.Normal,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.4f),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Filtering Layout Interface
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Type filter combo
                FilterChip(
                    selected = selectedTypeFilter == "ALL",
                    onClick = { selectedTypeFilter = "ALL" },
                    label = { Text("All Log") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = accentColor.copy(alpha = 0.2f),
                        selectedLabelColor = accentColor
                    )
                )
                FilterChip(
                    selected = selectedTypeFilter == "INCOME",
                    onClick = { selectedTypeFilter = "INCOME" },
                    label = { Text("Income") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF81C784).copy(alpha = 0.2f),
                        selectedLabelColor = Color(0xFF81C784)
                    )
                )
                FilterChip(
                    selected = selectedTypeFilter == "EXPENSE",
                    onClick = { selectedTypeFilter = "EXPENSE" },
                    label = { Text("Expense") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFFF5252).copy(alpha = 0.2f),
                        selectedLabelColor = Color(0xFFFF5252)
                    )
                )
            }

            // Wallet filter horizontal bar
            Text("FILTER BY WALLET NODE", fontSize = 10.sp, color = Color.White.copy(alpha = 0.4f), modifier = Modifier.padding(bottom = 6.dp))
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    AssistChip(
                        onClick = { selectedWalletFilter = "ALL" },
                        label = { Text("All Vaults") },
                        border = BorderStroke(1.dp, if (selectedWalletFilter == "ALL") accentColor else Color(0xFF102A4A)),
                        colors = AssistChipDefaults.assistChipColors(labelColor = if (selectedWalletFilter == "ALL") accentColor else Color.White)
                    )
                }
                items(wallets) { wallet ->
                    val isSelected = selectedWalletFilter == wallet.name
                    AssistChip(
                        onClick = { selectedWalletFilter = wallet.name },
                        label = { Text(wallet.name) },
                        border = BorderStroke(1.dp, if (isSelected) accentColor else Color(0xFF102A4A)),
                        colors = AssistChipDefaults.assistChipColors(labelColor = if (isSelected) accentColor else Color.White)
                    )
                }
            }

            // Ledger Output Records
            if (filteredTransactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.CloudQueue,
                            contentDescription = "Empty",
                            tint = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Secure local ledger represents zero matching records.",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredTransactions) { tx ->
                        TransactionListItem(
                            transaction = tx,
                            accentColor = accentColor,
                            onDelete = { viewModel.deleteTransaction(tx) }
                        )
                    }
                }
            }
        }
    }

    // Modal popup to register a new transaction log allocation
    if (showAddDialog) {
        AddTransactionDialog(
            categories = categories,
            wallets = wallets,
            accentColor = accentColor,
            onDismiss = { showAddDialog = false },
            onConfirm = { title, amount, type, category, wallet, note ->
                viewModel.addTransaction(title, amount, type, category, wallet, note = note)
                showAddDialog = false
            }
        )
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    categories: List<Category>,
    wallets: List<Wallet>,
    accentColor: Color,
    onDismiss: () -> Unit,
    onConfirm: (String, Double, String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("EXPENSE") } // EXPENSE or INCOME
    
    // Default dynamic selected category
    val filteredCats = categories.filter { it.isExpense == (type == "EXPENSE") }
    var selectedCategory by remember { mutableStateOf(filteredCats.firstOrNull()?.name ?: "") }
    var selectedWallet by remember { mutableStateOf(wallets.firstOrNull()?.name ?: "") }
    var note by remember { mutableStateOf("") }

    // Trigger state change of type to auto-filter category
    LaunchedEffect(type) {
        selectedCategory = categories.filter { it.isExpense == (type == "EXPENSE") }.firstOrNull()?.name ?: ""
    }

    val finalFilteredCats = categories.filter { it.isExpense == (type == "EXPENSE") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "AUTHORIZE NEW TRANSACTION",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor,
                letterSpacing = 1.sp
            )
        },
        containerColor = Color(0xFF081427),
        tonalElevation = 6.dp,
        modifier = Modifier.border(1.dp, accentColor, RoundedCornerShape(20.dp)),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Two toggle buttons: Expense or Income
                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { type = "EXPENSE" },
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (type == "EXPENSE") Color(0xFFFF5252) else Color(0xFF0F1E36)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Expense", color = Color.White)
                    }
                    Button(
                        onClick = { type = "INCOME" },
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (type == "INCOME") Color(0xFF66BB6A) else Color(0xFF0F1E36)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Income", color = Color.White)
                    }
                }

                // Title input field
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Allocation Title (e.g., Pizza, Salary)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = accentColor,
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = Color(0xFF102A4A)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Cost Amount input field
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Volume Amount (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = accentColor,
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = Color(0xFF102A4A)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Dropdowns of Categories
                Text("CATEGORY ASSIGNMENT", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                if (finalFilteredCats.isEmpty()) {
                    Text("No categories set. Create one first inside settings.", color = Color(0xFFFF5252), fontSize = 11.sp)
                } else {
                    var expandedCat by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = { expandedCat = true },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, Color(0xFF102A4A)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFF051020))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedCategory.ifEmpty { "Select Category" }, color = Color.White)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = accentColor)
                            }
                        }

                        DropdownMenu(
                            expanded = expandedCat,
                            onDismissRequest = { expandedCat = false },
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .background(Color(0xFF07152B))
                                .border(1.dp, accentColor)
                        ) {
                            finalFilteredCats.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name, color = Color.White) },
                                    onClick = {
                                        selectedCategory = cat.name
                                        expandedCat = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Dropdowns of Wallets
                Text("FUNDING ACCOUNT NODE", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                if (wallets.isEmpty()) {
                    Text("No wallets. Create one inside Budgets page first.", color = Color(0xFFFF5252), fontSize = 11.sp)
                } else {
                    var expandedWal by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = { expandedWal = true },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, Color(0xFF102A4A)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFF051020))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedWallet.ifEmpty { "Select Wallet" }, color = Color.White)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = accentColor)
                            }
                        }

                        DropdownMenu(
                            expanded = expandedWal,
                            onDismissRequest = { expandedWal = false },
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .background(Color(0xFF07152B))
                                .border(1.dp, accentColor)
                        ) {
                            wallets.forEach { wal ->
                                DropdownMenuItem(
                                    text = { Text(wal.name, color = Color.White) },
                                    onClick = {
                                        selectedWallet = wal.name
                                        expandedWal = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Dynamic Note allocation
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Secure Notes (e.g., Stark dinner)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = accentColor,
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = Color(0xFF102A4A)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val dblAmount = amount.toDoubleOrNull() ?: 0.0
                    if (title.isNotEmpty() && dblAmount > 0.0 && selectedCategory.isNotEmpty() && selectedWallet.isNotEmpty()) {
                        onConfirm(title, dblAmount, type, selectedCategory, selectedWallet, note)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("COMMIT", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ABORT", color = Color.White.copy(alpha = 0.5f))
            }
        }
    )
}


// ======================== SCREEN 3: BUDGETS & WALLETS (INTEGROUS SUBSYSTEMS) ========================

@Composable
fun BudgetsScreen(
    viewModel: MoneyViewModel,
    budgets: List<Budget>,
    transactions: List<Transaction>,
    categories: List<Category>,
    wallets: List<Wallet>,
    accentColor: Color
) {
    var showAddBudgetDialog by remember { mutableStateOf(false) }
    var showAddWalletDialog by remember { mutableStateOf(false) }

    // Aggregate expenditures by Category for current month
    val calendar = Calendar.getInstance()
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    val startOfMonth = calendar.timeInMillis

    val expenseTransactionsThisMonth = transactions.filter { it.type == "EXPENSE" && it.timestamp >= startOfMonth }
    
    val categoryExpenses = expenseTransactionsThisMonth
        .groupBy { it.categoryName }
        .mapValues { entry -> entry.value.sumOf { it.amount } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 80.dp)
    ) {
        // Budgeting Core Title
        item {
            Text(
                text = "SECURE BUDGET ENGINES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Define limits for custom containment protocols",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.4f),
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Add budget configuration block
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ONGOING PROTOCOL LIMITS", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Button(
                    onClick = { showAddBudgetDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Limit", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ALLOCATE", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Display budgets list
        if (budgets.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(12.dp))
                        .background(Color(0xFF071424).copy(alpha = 0.3f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No specific limits set this month, Sir.\nTap 'ALLOCATE' above to limit any category.",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(budgets) { budget ->
                val spent = categoryExpenses[budget.categoryName] ?: 0.0
                val percent = budget.limitAmount.let { (spent / it).toFloat() }.coerceIn(0f, 1f)
                val statusColor = if (percent >= 0.9f) Color(0xFFFF3D00) else if (percent >= 0.7f) Color(0xFFFFA726) else accentColor

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .border(1.dp, statusColor.copy(alpha = 0.25f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF09162E))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(budget.categoryName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            IconButton(
                                onClick = { viewModel.deleteBudget(budget.categoryName) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Delete Budget", tint = Color.White.copy(alpha = 0.4f), modifier = Modifier.size(14.dp))
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Cybernetic Linear Indicator
                        LinearProgressIndicator(
                            progress = percent,
                            color = statusColor,
                            trackColor = Color(0xFF102A4A),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Spent: Rp %,.0f".format(spent),
                                fontSize = 10.sp,
                                color = if (spent > budget.limitAmount) Color(0xFFFF5252) else Color.White.copy(alpha = 0.5f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "Core Limit: Rp %,.0f".format(budget.limitAmount),
                                fontSize = 10.sp,
                                color = accentColor,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // SECTION: WALLET NODES MANAGEMENT
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 28.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("VAULT NODES (WALLETS)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Button(
                    onClick = { showAddWalletDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add node", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ADD ACCOUNT", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Wallets list with delete icons in this screen specifically!
        if (wallets.isEmpty()) {
            item {
                Text("No vault accounts configured locally.", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp)
            }
        } else {
            items(wallets) { wallet ->
                val walletColor = try {
                    Color(android.graphics.Color.parseColor(wallet.colorHex))
                } catch (e: Exception) {
                    accentColor
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF071427))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(walletColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            val icon = when (wallet.iconName) {
                                "CreditCard" -> Icons.Default.CreditCard
                                "AccountBalance" -> Icons.Default.AccountBalance
                                "AccountBalanceWallet" -> Icons.Default.AccountBalanceWallet
                                else -> Icons.Default.Wallet
                            }
                            Icon(icon, contentDescription = "Wallet Icon", tint = walletColor)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(wallet.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                "System Node Account",
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 9.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "Rp %,.2f".format(wallet.balance),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                            IconButton(
                                onClick = { viewModel.deleteWallet(wallet) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Wallet", tint = Color(0xFFFF5252), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Allocate Limit popup dialog
    if (showAddBudgetDialog) {
        var limitAmount by remember { mutableStateOf("") }
        var selectedCatName by remember { mutableStateOf(categories.firstOrNull()?.name ?: "") }
        
        AlertDialog(
            onDismissRequest = { showAddBudgetDialog = false },
            title = { Text("CONFIRM BUDGET LIMIT", color = accentColor, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            containerColor = Color(0xFF081427),
            modifier = Modifier.border(1.dp, accentColor, RoundedCornerShape(16.dp)),
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select containment category to apply strict limit protocol.", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                    
                    var expandedCat by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = { expandedCat = true },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, Color(0xFF102A4A)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFF051020))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedCatName.ifEmpty { "Select Category" }, color = Color.White)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = accentColor)
                            }
                        }

                        DropdownMenu(
                            expanded = expandedCat,
                            onDismissRequest = { expandedCat = false },
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .background(Color(0xFF07152B))
                                .border(1.dp, accentColor)
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name, color = Color.White) },
                                    onClick = {
                                        selectedCatName = cat.name
                                        expandedCat = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = limitAmount,
                        onValueChange = { limitAmount = it },
                        label = { Text("Max Limit (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accentColor,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF102A4A)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val limit = limitAmount.toDoubleOrNull() ?: 0.0
                        if (selectedCatName.isNotEmpty() && limit > 0.0) {
                            viewModel.addBudget(selectedCatName, limit)
                            showAddBudgetDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("ACTIVATE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBudgetDialog = false }) {
                    Text("ABORT", color = Color.White.copy(alpha = 0.5f))
                }
            }
        )
    }

    // Add wallet popup dialog
    if (showAddWalletDialog) {
        var walletName by remember { mutableStateOf("") }
        var initialBalance by remember { mutableStateOf("") }
        var walletIcon by remember { mutableStateOf("Wallet") }
        var walletColor by remember { mutableStateOf("#00E5FF") }

        AlertDialog(
            onDismissRequest = { showAddWalletDialog = false },
            title = { Text("AUTHORIZE SECURE ACCOUNT", color = accentColor, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            containerColor = Color(0xFF081427),
            modifier = Modifier.border(1.dp, accentColor, RoundedCornerShape(16.dp)),
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = walletName,
                        onValueChange = { walletName = it },
                        label = { Text("Account Name (e.g., Cash, Stark Card)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accentColor,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF102A4A)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = initialBalance,
                        onValueChange = { initialBalance = it },
                        label = { Text("Initial Balance (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accentColor,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF102A4A)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Wallet Icons selector
                    Text("ACC-NODE ICON", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("Wallet", "CreditCard", "AccountBalance", "AccountBalanceWallet").forEach { ic ->
                            val vectorIcon = when (ic) {
                                "CreditCard" -> Icons.Default.CreditCard
                                "AccountBalance" -> Icons.Default.AccountBalance
                                "AccountBalanceWallet" -> Icons.Default.AccountBalanceWallet
                                else -> Icons.Default.Wallet
                            }
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        1.5.dp,
                                        if (walletIcon == ic) accentColor else Color(0xFF102A4A),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .background(if (walletIcon == ic) accentColor.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { walletIcon = ic },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(vectorIcon, contentDescription = ic, tint = if (walletIcon == ic) accentColor else Color.White)
                            }
                        }
                    }

                    // Theme Colors Picker
                    Text("ACC-NODE HOLOGRAPHIC ACCENT", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("#00E5FF", "#FFA726", "#FF3D00", "#78909C", "#E040FB", "#00E676").forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(hex)))
                                    .border(
                                        if (walletColor == hex) 3.dp else 1.dp,
                                        if (walletColor == hex) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable { walletColor = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val bal = initialBalance.toDoubleOrNull() ?: 0.0
                        if (walletName.isNotEmpty()) {
                            viewModel.addWallet(walletName, bal, walletIcon, walletColor)
                            showAddWalletDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("ADD CORE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddWalletDialog = false }) {
                    Text("ABORT", color = Color.White.copy(alpha = 0.5f))
                }
            }
        )
    }
}


// ======================== SCREEN 4: JARVIS CHAT PROTOCOL ========================

@Composable
fun JarvisChatScreen(
    viewModel: MoneyViewModel,
    accentColor: Color
) {
    val chatHistory by viewModel.chatHistory.collectAsStateWithLifecycle()
    val isThinking by viewModel.isJarvisThinking.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var userMessageText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Scroll to latest message on history update
    LaunchedEffect(chatHistory.size, isThinking) {
        if (chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(chatHistory.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Chat Header Title
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "JARVIS MAINFRAME DIRECTLINK",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "A.I. Tactical Financial Diagnostic Subsystems",
                    fontSize = 11.sp,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            IconButton(
                onClick = { viewModel.clearChat() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF0E223D))
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Defragment chat logs", tint = accentColor)
            }
        }

        // Rolling Conversation Logs
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 10.dp)
                .border(1.dp, Color(0xFF102A4A).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .background(Color(0xFF030A18).copy(alpha = 0.85f))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(chatHistory, key = { it.id }) { msg ->
                val aligning = if (msg.isUser) Alignment.End else Alignment.Start
                val alignmentColumn = if (msg.isUser) TextAlign.End else TextAlign.Start
                val chatColor = if (msg.isUser) accentColor.copy(alpha = 0.15f) else Color(0xFF0C1B33)
                val strokeVal = if (msg.isUser) accentColor else Color(0xFF122E54)
                
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = aligning
                ) {
                    Text(
                        text = if (msg.isUser) "AUTHORIZATION PROTOCOL" else "JARVIS TERMINAL",
                        fontSize = 8.sp,
                        color = if (msg.isUser) accentColor else Color.White.copy(alpha = 0.4f),
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(chatColor)
                            .border(1.dp, strokeVal, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg.text,
                            color = Color.White,
                            fontSize = 13.sp,
                            textAlign = alignmentColumn
                        )
                    }
                }
            }

            // Pulsing Holographic AI loading visualizer
            if (isThinking) {
                item {
                    val infiniteTransition = rememberInfiniteTransition(label = "hologram_waves")
                    val pulseAlpha by infiniteTransition.animateFloat(
                        initialValue = 0.3f,
                        targetValue = 1.0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(700, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulse_alpha"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(accentColor.copy(alpha = pulseAlpha))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "JARVIS is parsing dynamic vectors (analyzing offline ledger)...",
                            fontSize = 11.sp,
                            color = accentColor.copy(alpha = pulseAlpha),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Dynamic presets for tactical prompt selection
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val presets = listOf(
                "Diagnosa keuangan saya, Sir?" to "Berikan analisis diagnosa taktis keuangan saya minggu ini. Apakah pengeluaran saya bertenaga reaktor penuh?",
                "Saran penghematan Stark" to "Berikan saran penghematan taktis yang elegan ala Jarvis untuk mengoptimalkan cash flow saya.",
                "Cek batas reaktor / budget" to "Tinjau ongoing budget dan sisa balance tabungan saya. Apa rekomendasi Anda?"
            )
            presets.forEach { pair ->
                ElevatedAssistChip(
                    onClick = {
                        viewModel.askJarvis(pair.second)
                    },
                    label = { Text(pair.first, fontSize = 10.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = Color(0xFF0A182E),
                        labelColor = accentColor
                    ),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.3f))
                )
            }
        }

        // Direct manual prompt terminal input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = userMessageText,
                onValueChange = { userMessageText = it },
                placeholder = { Text("Transmit command/consultation to Jarvis...", color = Color.White.copy(alpha = 0.3f)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = accentColor,
                    focusedBorderColor = accentColor,
                    unfocusedBorderColor = Color(0xFF0F2B4D)
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("jarvis_chat_input"),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (userMessageText.isNotBlank()) {
                        viewModel.askJarvis(userMessageText)
                        userMessageText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor)
                    .testTag("jarvis_chat_send")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Transmit", tint = Color.Black)
            }
        }
    }
}


// ======================== SCREEN 5: CLEARANCE & CONFIGURATION (SETTINGS) ========================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: MoneyViewModel,
    accentColor: Color,
    categories: List<Category>,
    userName: String,
    userEmail: String,
    isLoggedIn: Boolean,
    clearanceLevel: String,
    avatarType: String
) {
    val coroutineScope = rememberCoroutineScope()
    var showCategoryCreator by remember { mutableStateOf(false) }

    // State for local Google Account login/switching dialog
    var showGoogleAuthDialogue by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Settings Central title
        item {
            Text(
                text = "CLEARANCE CONTROL PANEL",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Configure user authorization level, visual identity, and core segments",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.4f),
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // GOGOOGLE SYSTEM SECURITY SECTION
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(1.2.dp, Brush.horizontalGradient(listOf(accentColor, Color.Transparent))),
                        RoundedCornerShape(16.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF060F1E))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STARK ENCRYPTED DELEGATION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            letterSpacing = 1.sp
                        )
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (isLoggedIn) Color(0xFF66BB6A) else Color(0xFFFF5252), CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (isLoggedIn) Icons.Default.Verified else Icons.Default.Face,
                            contentDescription = "User info",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = userName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (userEmail.isNotEmpty()) userEmail else "Guest Account Protocol Active",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color(0xFF112847))
                    Spacer(modifier = Modifier.height(14.dp))

                    if (isLoggedIn) {
                        Button(
                            onClick = { viewModel.logOut() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = "Unlink", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("DISCONNECT ACCOUNT", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = { showGoogleAuthDialogue = true },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                            modifier = Modifier.fillMaxWidth()
                                .testTag("google_login_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PowerSettingsNew, contentDescription = "Link", tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("LINK GOOGLE ACCOUNT", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // STARK VISUAL THEMING CUSTOMIZER
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF071427))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "HOLOGRAPHIC THEME RE-CALIBRATION",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Accent Colors List selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val armorColors = listOf(
                            "Arc-Reactor Blue" to "#00E5FF",
                            "Titanium Red" to "#FF3D00",
                            "Armor Gold" to "#FFA726",
                            "Metal Silver" to "#90A4AE"
                        )
                        armorColors.forEach { (name, hex) ->
                            val colorRepresentation = Color(android.graphics.Color.parseColor(hex))
                            val isSelected = accentColor == colorRepresentation

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable {
                                        viewModel.updateThemeAccent(hex)
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(colorRepresentation.copy(alpha = if (isSelected) 0.35f else 0.1f))
                                    .border(
                                        if (isSelected) 2.5.dp else 1.dp,
                                        if (isSelected) colorRepresentation else colorRepresentation.copy(alpha = 0.5f),
                                        CircleShape
                                    ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(colorRepresentation)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = name.substringAfter("-"),
                                    fontSize = 9.sp,
                                    color = if (isSelected) accentColor else Color.White.copy(alpha = 0.5f),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }

        // SEGMENTS: CATEGORY DATA DICTIONARY CORES
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF102A4A), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF071427))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "VALENCY CATEGORY ENGINE",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )
                        IconButton(
                            onClick = { showCategoryCreator = true },
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(accentColor)
                                .testTag("add_category_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "New Category", tint = Color.Black, modifier = Modifier.size(16.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { cat ->
                            val catColor = try {
                                Color(android.graphics.Color.parseColor(cat.colorHex))
                            } catch (e: Exception) {
                                accentColor
                            }

                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(catColor.copy(alpha = 0.12f))
                                    .border(1.dp, catColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = (if (cat.isExpense) "🔻 " else "🔺 ") + cat.name,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Delete Category",
                                    tint = Color.White.copy(alpha = 0.4f),
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clickable { viewModel.deleteCategory(cat) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Google Profile login customizer modal block
    if (showGoogleAuthDialogue) {
        var authName by remember { mutableStateOf("") }
        var authEmail by remember { mutableStateOf("") }
        var chosenAvatar by remember { mutableStateOf("JarvisAdmin") }
        var chosenClearance by remember { mutableStateOf("Omega Clearance") }

        AlertDialog(
            onDismissRequest = { showGoogleAuthDialogue = false },
            title = {
                Text(
                    "GOOGLE IDENTITY SECURITY PROTOCOLS",
                    color = accentColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            },
            containerColor = Color(0xFF081427),
            modifier = Modifier.border(1.dp, accentColor, RoundedCornerShape(16.dp)),
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        "We can safely simulate OAuth credentials binding to locally establish authorized clearances offline, Sir.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )

                    OutlinedTextField(
                        value = authName,
                        onValueChange = { authName = it },
                        label = { Text("Display Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accentColor,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF102A4A)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = authEmail,
                        onValueChange = { authEmail = it },
                        label = { Text("Google Account Email") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accentColor,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF102A4A)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("SELECT SYSTEM AVATAR", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("Stark", "Rescue", "WarMachine", "JarvisAdmin").forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        1.5.dp,
                                        if (chosenAvatar == tag) accentColor else Color(0xFF102A4A),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .background(if (chosenAvatar == tag) accentColor.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { chosenAvatar = tag },
                                contentAlignment = Alignment.Center
                            ) {
                                val vectorIcon = when (tag) {
                                    "Stark" -> Icons.Default.Shield
                                    "Rescue" -> Icons.Default.MonitorHeart
                                    "WarMachine" -> Icons.Default.MilitaryTech
                                    else -> Icons.Default.SmartToy
                                }
                                Icon(vectorIcon, contentDescription = tag, tint = if (chosenAvatar == tag) accentColor else Color.White)
                            }
                        }
                    }

                    Text("CLEARANCE DELEGATION", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                    listOf("Omega Clearance", "Core Director", "Stark Agent", "Level 4 Guest").forEach { level ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { chosenClearance = level }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = chosenClearance == level,
                                onClick = { chosenClearance = level },
                                colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(level, color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = authName.ifEmpty { "Agent JHOVAN" }
                        val email = authEmail.ifEmpty { "atysinr@gmail.com" }
                        viewModel.updateProfile(name, email, true, chosenAvatar, chosenClearance)
                        showGoogleAuthDialogue = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("AUTHORIZE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGoogleAuthDialogue = false }) {
                    Text("ABORT", color = Color.White.copy(alpha = 0.5f))
                }
            }
        )
    }

    // Category Creator Customization Popup
    if (showCategoryCreator) {
        var catName by remember { mutableStateOf("") }
        var catColor by remember { mutableStateOf("#00E5FF") }
        var isExpense by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showCategoryCreator = false },
            title = { Text("GENERATE CUSTOM CATEGORY VECT", color = accentColor, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            containerColor = Color(0xFF081427),
            modifier = Modifier.border(1.dp, accentColor, RoundedCornerShape(16.dp)),
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("Category Core Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accentColor,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF102A4A)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { isExpense = true },
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (isExpense) Color(0xFFFF5252) else Color(0xFF0F1E36)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Expense")
                        }
                        Button(
                            onClick = { isExpense = false },
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (!isExpense) Color(0xFF66BB6A) else Color(0xFF0F1E36)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Income")
                        }
                    }

                    Text("HOLOGRAPHIC COLOR ACCENT", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("#00E5FF", "#FFA726", "#FF3D00", "#78909C", "#E040FB", "#00E676").forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(hex)))
                                    .border(
                                        if (catColor == hex) 3.dp else 1.dp,
                                        if (catColor == hex) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable { catColor = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (catName.isNotEmpty()) {
                            viewModel.addCategory(catName, "Category", catColor, isExpense)
                            showCategoryCreator = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("GENERATE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCategoryCreator = false }) {
                    Text("ABORT")
                }
            }
        )
    }
}
