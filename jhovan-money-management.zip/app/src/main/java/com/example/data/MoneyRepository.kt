package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MoneyRepository(private val moneyDao: MoneyDao) {

    val allTransactions: Flow<List<Transaction>> = moneyDao.getAllTransactions()
    val allCategories: Flow<List<Category>> = moneyDao.getAllCategories()
    val allWallets: Flow<List<Wallet>> = moneyDao.getAllWallets()
    val allBudgets: Flow<List<Budget>> = moneyDao.getAllBudgets()

    suspend fun insertTransaction(transaction: Transaction) {
        // Fetch matching wallet
        val walletsList = moneyDao.getAllWallets().first()
        val wallet = walletsList.find { it.name == transaction.walletName }
        
        if (wallet != null) {
            val balanceAdjustment = if (transaction.type == "INCOME") {
                transaction.amount
            } else {
                -transaction.amount
            }
            val newBalance = wallet.balance + balanceAdjustment
            moneyDao.updateWalletBalance(wallet.name, newBalance)
        }
        
        moneyDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: Transaction) {
        // Fetch matching wallet and reverse adjustment
        val walletsList = moneyDao.getAllWallets().first()
        val wallet = walletsList.find { it.name == transaction.walletName }
        
        if (wallet != null) {
            val reverseAdjustment = if (transaction.type == "INCOME") {
                -transaction.amount
            } else {
                transaction.amount
            }
            val newBalance = wallet.balance + reverseAdjustment
            moneyDao.updateWalletBalance(wallet.name, newBalance)
        }
        
        moneyDao.deleteTransaction(transaction)
    }

    // Category actions
    suspend fun insertCategory(category: Category) = moneyDao.insertCategory(category)
    suspend fun deleteCategory(category: Category) = moneyDao.deleteCategory(category)

    // Wallet actions
    suspend fun insertWallet(wallet: Wallet) = moneyDao.insertWallet(wallet)
    suspend fun deleteWallet(wallet: Wallet) = moneyDao.deleteWallet(wallet)

    // Budget actions
    suspend fun insertBudget(budget: Budget) = moneyDao.insertBudget(budget)
    suspend fun deleteBudgetByCategory(categoryName: String) = moneyDao.deleteBudgetByCategory(categoryName)
}
