package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun MyApplicationTheme(
    accentColorHex: String = "#00E5FF",
    content: @Composable () -> Unit
) {
    // Parse the user's customized theme accent hex
    val parsedAccent = try {
        Color(android.graphics.Color.parseColor(accentColorHex))
    } catch (e: Exception) {
        NeonCyanGlow
    }

    val colorScheme = darkColorScheme(
        primary = parsedAccent,
        onPrimary = Color.Black,
        primaryContainer = parsedAccent.copy(alpha = 0.15f),
        onPrimaryContainer = parsedAccent,
        secondary = ArmorGoldGlow,
        onSecondary = Color.Black,
        secondaryContainer = ArmorGoldGlow.copy(alpha = 0.15f),
        onSecondaryContainer = ArmorGoldGlow,
        tertiary = TitaniumSilver,
        onTertiary = Color.Black,
        background = JarvisBgMidnight,
        onBackground = Color.White,
        surface = JarvisCardBg,
        onSurface = Color.White,
        surfaceVariant = JarvisBorderColor,
        onSurfaceVariant = TitaniumSilver,
        error = CopperReactorRed,
        onError = Color.White,
        outline = parsedAccent.copy(alpha = 0.5f)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
