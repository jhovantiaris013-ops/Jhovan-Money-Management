package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val amount: Double,
    val type: String, // "INCOME", "EXPENSE"
    val categoryName: String,
    val walletName: String,
    val timestamp: Long,
    val note: String = ""
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val name: String,
    val iconName: String, // Name of material icon
    val colorHex: String, // Hex code like #FF00FF
    val isExpense: Boolean
)

@Entity(tableName = "wallets")
data class Wallet(
    @PrimaryKey val name: String,
    val balance: Double,
    val iconName: String,
    val colorHex: String
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey val categoryName: String,
    val limitAmount: Double
)
