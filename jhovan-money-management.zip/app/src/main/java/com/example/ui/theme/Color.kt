package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Space & Iron Man cybernetic background colors
val JarvisBgMidnight = Color(0xFF030812) // Pure deep hologram background
val JarvisCardBg = Color(0xFF081427)     // Translucent tech card backing
val JarvisBorderColor = Color(0xFF102A4A)  // Frame lines

// Dynamic Glowing Accents
val NeonCyanGlow = Color(0xFF00E5FF)      // Mark 85 core power reactor
val ArmorGoldGlow = Color(0xFFFFA726)     // Stark plated gold
val CopperReactorRed = Color(0xFFFF3D00)   // High expense indicator / warning
val TitaniumSilver = Color(0xFFCFD8DC)     // Metal lining interface

// Traditional Material complementary dark tokens
val PrimaryDark = Color(0xFF00E5FF)
val SecondaryDark = Color(0xFFFFA726)
val TertiaryDark = Color(0xFFCFD8DC)
val BackgroundDark = Color(0xFF030812)
val SurfaceDark = Color(0xFF081427)
