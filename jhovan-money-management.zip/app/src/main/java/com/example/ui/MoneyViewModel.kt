package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class JarvisChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class MoneyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = MoneyRepository(database.moneyDao())
    private val preferenceManager = PreferenceManager(application)
    private val jarvisAiService = JarvisAiService()

    // --- State Flows from Room Database ---
    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val wallets: StateFlow<List<Wallet>> = repository.allWallets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgets: StateFlow<List<Budget>> = repository.allBudgets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- State Flows from PreferenceManager (User settings) ---
    val userName: StateFlow<String> = preferenceManager.userNameFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Agent JHOVAN")

    val userEmail: StateFlow<String> = preferenceManager.userEmailFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "atysinr@gmail.com")

    val isLoggedIn: StateFlow<Boolean> = preferenceManager.isLoggedInFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val profileAvatar: StateFlow<String> = preferenceManager.profileAvatarFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "JarvisAdmin")

    val clearanceLevel: StateFlow<String> = preferenceManager.clearanceLevelFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Omega Clearance")

    val themeAccentColor: StateFlow<String> = preferenceManager.themeAccentColorFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "#00E5FF")

    val jarvisChatterFreq: StateFlow<Float> = preferenceManager.jarvisChatterFreqFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.8f)


    // --- Jarvis AI Conversation System State ---
    private val _chatHistory = MutableStateFlow<List<JarvisChatMessage>>(
        listOf(
            JarvisChatMessage(
                text = "Protokol keamanan diaktifkan, Sir. Saya JARVIS, asisten virtual Anda. Sistem keuangan Anda sepenuhnya offline dan aman. Ada modul taktis yang bisa saya bantu hari ini?",
                isUser = false
            )
        )
    )
    val chatHistory: StateFlow<List<JarvisChatMessage>> = _chatHistory.asStateFlow()

    private val _isJarvisThinking = MutableStateFlow(false)
    val isJarvisThinking: StateFlow<Boolean> = _isJarvisThinking.asStateFlow()


    // --- Transaction Actions ---
    fun addTransaction(
        title: String,
        amount: Double,
        type: String, // "INCOME" or "EXPENSE"
        categoryName: String,
        walletName: String,
        timestamp: Long = System.currentTimeMillis(),
        note: String = ""
    ) {
        viewModelScope.launch {
            repository.insertTransaction(
                Transaction(
                    title = title,
                    amount = amount,
                    type = type,
                    categoryName = categoryName,
                    walletName = walletName,
                    timestamp = timestamp,
                    note = note
                )
            )
            // Ask Jarvis to briefly respond in background chatter if chatter frequency is high!
            triggerJarvisChatterAfterTx(title, amount, type)
        }
    }

    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            addSystemDiagnosticLog("Transaksi '${transaction.title}' telah dihapus dari basis data lokal.")
        }
    }


    // --- Category Actions ---
    fun addCategory(name: String, iconName: String, colorHex: String, isExpense: Boolean) {
        viewModelScope.launch {
            repository.insertCategory(Category(name, iconName, colorHex, isExpense))
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
        }
    }


    // --- Wallet Actions ---
    fun addWallet(name: String, balance: Double, iconName: String, colorHex: String) {
        viewModelScope.launch {
            repository.insertWallet(Wallet(name, balance, iconName, colorHex))
        }
    }

    fun deleteWallet(wallet: Wallet) {
        viewModelScope.launch {
            repository.deleteWallet(wallet)
        }
    }


    // --- Budget Actions ---
    fun addBudget(categoryName: String, limitAmount: Double) {
        viewModelScope.launch {
            repository.insertBudget(Budget(categoryName, limitAmount))
        }
    }

    fun deleteBudget(categoryName: String) {
        viewModelScope.launch {
            repository.deleteBudgetByCategory(categoryName)
        }
    }


    // --- Settings Actions ---
    fun updateProfile(name: String, email: String, isLoggedIn: Boolean, avatar: String, clearance: String) {
        viewModelScope.launch {
            preferenceManager.saveProfile(name, email, isLoggedIn, avatar, clearance)
            val loginAlert = if (isLoggedIn) "Google Profile terhubung." else "Mengaktifkan Guest Protocol."
            _chatHistory.value = _chatHistory.value + JarvisChatMessage(
                text = "Identitas diperbarui, Sir. Selamat datang kembali, $name. Otorisasi keamanan tingkat '$clearance' diakreditasi. $loginAlert",
                isUser = false
            )
        }
    }

    fun updateThemeAccent(colorHex: String) {
        viewModelScope.launch {
            preferenceManager.saveThemeAccent(colorHex)
            addSystemDiagnosticLog("Skema warna visual dialihkan ke kode heksadesimal: $colorHex.")
        }
    }

    fun updateJarvisChatter(frequency: Float) {
        viewModelScope.launch {
            preferenceManager.saveJarvisChatterFreq(frequency)
        }
    }

    fun logOut() {
        viewModelScope.launch {
            preferenceManager.clearSession()
            _chatHistory.value = _chatHistory.value + JarvisChatMessage(
                text = "Akun telah diputus, Sir. Sistem dikembalikan ke Protokol Tamu (Decoupled Guest Protocol). Semua data Anda tetap aman secara lokal di perangkat ini.",
                isUser = false
            )
        }
    }


    // --- Jarvis AI Engagement Platform ---
    fun askJarvis(question: String) {
        if (question.isBlank()) return
        
        val userMsg = JarvisChatMessage(text = question, isUser = true)
        _chatHistory.value = _chatHistory.value + userMsg
        _isJarvisThinking.value = true

        viewModelScope.launch {
            // Marshall local states to JSON string representation so Jarvis can inspect them
            val txJson = transactions.value.take(15).map { 
                mapOf("judul" to it.title, "jumlah" to it.amount, "tipe" to it.type, "kategori" to it.categoryName)
            }.toString()

            val walletJson = wallets.value.map { 
                mapOf("dompet" to it.name, "saldo" to it.balance)
            }.toString()

            val budgetJson = budgets.value.map { 
                mapOf("kategori" to it.categoryName, "limit" to it.limitAmount)
            }.toString()

            val response = jarvisAiService.consultJarvis(
                userName = userName.value,
                prompt = question,
                transactionsJson = txJson,
                budgetsJson = budgetJson,
                walletsJson = walletJson
            )

            _chatHistory.value = _chatHistory.value + JarvisChatMessage(
                text = response,
                isUser = false
            )
            _isJarvisThinking.value = false
        }
    }

    private fun triggerJarvisChatterAfterTx(title: String, amount: Double, type: String) {
        if (jarvisChatterFreq.value < 0.3f) return // Respect user's low chatter choice
        
        viewModelScope.launch {
            val isExpense = type == "EXPENSE"
            val stateText = if (isExpense) "pengeluaran taktis" else "pemasukan baru"
            val chatter = if (isExpense) {
                if (amount > 1000000) {
                    "Catatan tambahan, Sir. Transaksi '$title' sebesar Rp %,.2f terdeteksi. Pengurangan energi reaktor yang cukup signifikan, mohon ditinjau kembali.".format(amount)
                } else {
                    "Saya telah mendokumentasikan pengeluaran '$title' ke dalam basis data hemat daya, Sir."
                }
            } else {
                "Pemasukan taktis terkonfirmasi: '$title' sebesar Rp %,.2f. Reaktor kian bertenaga, Sir!".format(amount)
            }
            
            _chatHistory.value = _chatHistory.value + JarvisChatMessage(
                text = chatter,
                isUser = false
            )
        }
    }

    private fun addSystemDiagnosticLog(log: String) {
        _chatHistory.value = _chatHistory.value + JarvisChatMessage(
            text = "🔩 [DIAGNOSTIC] $log",
            isUser = false
        )
    }

    fun clearChat() {
        _chatHistory.value = listOf(
            JarvisChatMessage(
                text = "Antarmuka chat didefragmentasi untuk optimasi memori, Sir. Siap memisahkan log pengeluaran baru Anda.",
                isUser = false
            )
        )
    }
}
